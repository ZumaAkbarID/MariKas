<ul class="side-menu">
    <?php if(Auth::check()): ?>
        <li>
            <a href="<?php echo e(route('Dashboard')); ?>">
                <i class='bx bxs-dashboard icon'></i> Dashboard
            </a>
        </li>
    <?php else: ?>
        <li>
            <a href="<?php echo e(route('Auth_login')); ?>">
                <i class='bx bxs-user icon'></i> Masuk
            </a>
        </li>
    <?php endif; ?>
    <li>
        <a href="<?php echo e(route('Kas_EachMonth')); ?>" class="<?php if(Request::segment(1) == 'kas'): ?> active <?php endif; ?>">
            <i class='bx bxs-dashboard icon'></i> Kas
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('Kas_Index')); ?>" class="<?php if(Request::segment(1) == 'kalendar'): ?> active <?php endif; ?>">
            <i class='bx bxs-dashboard icon'></i> Kas Kalendar
        </a>
    </li>
    <li>
        <a href="<?php echo e(url('/')); ?>" class="<?php if(Request::segment(1) == ''): ?> active <?php endif; ?>">
            <i class='bx bxs-dashboard icon'></i> Bayar Kas
        </a>
    </li>
</ul>
<?php /**PATH D:\Laragon\laragon-zuma\www\MariKas\resources\views/Layouts/front_menu.blade.php ENDPATH**/ ?>