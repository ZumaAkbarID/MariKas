

<?php $__env->startSection('app_content'); ?>
    <div class="content-start transition">
        <div class="container-fluid dashboard">
            <div class="row justify-content-center">
                <div class="col-sm-12 col-lg-6">
                    <div class="card bg-white rounded p-4">
                        <div class="card-content">
                            <form action="" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group my-3">
                                    <label for="name">Nama</label>
                                    <input type="text" name="name" id="name"
                                        class="form-control <?php if($errors->has('name')): ?> is-invalid <?php endif; ?>" required
                                        value="<?php echo e(old('name')); ?>" placeholder="cnth: Ay ang">
                                </div>

                                <div class="form-group my-3">
                                    <label for="phone_number">Nomor WhatsApp</label>
                                    <input type="text" name="phone_number" id="phone_number"
                                        class="form-control <?php if($errors->has('phone_number')): ?> is-invalid <?php endif; ?>" required
                                        value="<?php echo e(old('phone_number')); ?>" placeholder="08xxx atau 628xxx">
                                </div>

                                

                                <div class="form-group my-3">
                                    <label for="amount">Jumlah x Pembayaran</label>
                                    <input type="number" name="amount" id="amount" min="1"
                                        class="form-control <?php if($errors->has('amount')): ?> is-invalid <?php endif; ?>" required
                                        value="<?php echo e(old('amount')); ?>" placeholder="cnth: 2">
                                    <span class="text-secondary">Berapa minggu</span>
                                </div>

                                <img src="https://via.placeholder.com/150x300.png?text=Image+preview" class="img-fluid"
                                    alt="" id="imgPreview">
                                <div class="form-group my-3">
                                    <label for="payment_proof">Bukti Pembayaran</label>
                                    <input type="file" name="payment_proof" id="payment_proof"
                                        class="form-control <?php if($errors->has('payment_proof')): ?> is-invalid <?php endif; ?>" required>
                                </div>

                                <div class="form-group my-3">
                                    <label for="status">Status</label>
                                    <select name="status" id="status" class="form-control">
                                        <option value="approved" selected>Lunas</option>
                                        
                                    </select>
                                </div>

                                <div class="form-group my-3">
                                    <div class="row">
                                        <div class="col-lg-10 col-sm-8"></div>
                                        <div class="col-lg-2 col-sm-4">
                                            <button class="btn btn-primary">Simpan</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('app_js'); ?>
    <script>
        $(document).ready(() => {
            $('#payment_proof').change(function() {
                const file = this.files[0];
                console.log(file);
                if (file) {
                    let reader = new FileReader();
                    reader.onload = function(event) {
                        console.log(event.target.result);
                        $('#imgPreview').attr('src', event.target.result);
                    }
                    reader.readAsDataURL(file);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laragon\laragon-zuma\www\MariKas\resources\views/Pemilik/manual.blade.php ENDPATH**/ ?>