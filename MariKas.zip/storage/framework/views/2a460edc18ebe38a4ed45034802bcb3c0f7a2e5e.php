

<?php $__env->startSection('app_content'); ?>
    <div class="content-start transition">
        <div class="container-fluid dashboard">
            <div class="row justify-content-center">
                <div class="col-sm-12 col-lg-4">
                    <div class="card">
                        <div class="card-content">
                            <?php if($data['message'] == 'Whatsapp instance connected successfully'): ?>
                                <div class="alert alert-success">WhatsApp sudah terhubung dengan nomor
                                    <?php echo e($data['data']['phone_number']); ?></div>
                            <?php else: ?>
                                <img class="img-fluid w-100" src="<?php echo e($data['qr_url']); ?>">
                            <?php endif; ?>
                        </div>
                        <div class="card-footer d-flex justify-content-between">
                            
                            <?php if($data['message'] !== 'Whatsapp instance connected successfully'): ?>
                                <button class="btn btn-light-primary" onclick="location.reload()">Refresh</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('app_js'); ?>
    <script>
        function NotAvailable() {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Provider penyedia API belum support',
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laragon\laragon-zuma\www\MariKas\resources\views/API/FastWA/connect.blade.php ENDPATH**/ ?>