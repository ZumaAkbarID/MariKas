<footer>
    <div class="footer">
        <div class="float-start">
            <p>2022 - <?php echo e(date('Y')); ?> &copy; <?php echo e($config['app_name']); ?> |
                <?php echo e(round(microtime(true) - LARAVEL_START, 3)); ?> detik waktu render</p>
        </div>
        <div class="float-end">
            <p>Created with
                <span class="text-danger">
                    <i class="fa fa-heart"></i>
                </span>
                by
                <a href="#" class="author-footer"><?php echo e($config['app_name']); ?> Team</a>
            </p>
        </div>
    </div>
</footer>
<?php /**PATH D:\Laragon\laragon-zuma\www\MariKas\resources\views/Layouts/app_footer.blade.php ENDPATH**/ ?>