<!doctype html>
<html lang="en">

<head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e($title); ?></title>

    <link rel="shortcut icon" href="<?php echo e(asset('storage/assets')); ?>/<?php echo e($config['app_favicon']); ?>" type="image/x-icon">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('storage')); ?>/assets/modules/bootstrap-5.1.3/css/bootstrap.css">
    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('storage')); ?>/assets/css/style.css">
    <!-- FontAwesome CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('storage')); ?>/assets/modules/fontawesome6.1.1/css/all.css">
    <!-- Boxicons CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('storage')); ?>/assets/modules/boxicons/css/boxicons.min.css">
    <!-- Apexcharts  CSS -->
    
    <!-- SweetAlert CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('storage')); ?>/assets/modules/sweetalert/sweetalert.min.css">
</head>

<body>

    <!--Topbar -->
    <?php echo $__env->make('Layouts.app_topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--Sidebar-->
    <?php echo $__env->make('Layouts.app_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Sidebar-->


    <div class="sidebar-overlay"></div>


    <!--Content Start-->
    <?php echo $__env->yieldContent('app_content'); ?>


    <!-- Footer -->
    <?php echo $__env->make('Layouts.app_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- Preloader -->
    <div class="loader">
        <div class="spinner-border text-light" role="status">
            <span class="sr-only">Tunggu sebentar...</span>
        </div>
    </div>

    <!-- Loader -->
    <div class="loader-overlay"></div>

    <!-- General JS Scripts -->
    <script src="<?php echo e(asset('storage')); ?>/assets/js/marikas.js"></script>

    <!-- JS Libraies -->
    <script src="<?php echo e(asset('storage')); ?>/assets/modules/jquery/jquery.min.js"></script>
    <script src="<?php echo e(asset('storage')); ?>/assets/modules/bootstrap-5.1.3/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('storage')); ?>/assets/modules/popper/popper.min.js"></script>

    <!-- SweetAlert Js -->
    <script src="<?php echo e(asset('storage')); ?>/assets/modules/sweetalert/sweetalert.all.min.js"></script>

    <!-- Chart Js -->
    

    <!-- Template JS File -->
    <script src="<?php echo e(asset('storage')); ?>/assets/js/script.js"></script>
    <script src="<?php echo e(asset('storage')); ?>/assets/js/custom.js"></script>
    <script>
        <?php if(session()->has('error')): ?>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                html: "<?php echo session('error'); ?>"
            });
        <?php endif; ?>
        <?php if(session()->has('success')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Yay...',
                html: "<?php echo session('success'); ?>"
            });
        <?php endif; ?>
    </script>
    <?php echo $__env->yieldContent('app_js'); ?>
</body>

</html>
<?php /**PATH D:\Laragon\laragon-zuma\www\MariKas\resources\views/Layouts/app.blade.php ENDPATH**/ ?>